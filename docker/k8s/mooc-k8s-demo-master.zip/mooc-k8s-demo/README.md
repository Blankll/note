# mooc-k8s-demo

#### 项目介绍
本项目对应慕课网实战课第六章《业务系统迁移kubernetes - 最佳实践》中的迁移docker之前的初始代码
