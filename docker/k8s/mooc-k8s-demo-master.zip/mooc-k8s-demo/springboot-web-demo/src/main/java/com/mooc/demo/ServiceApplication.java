package com.mooc.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Created by Michael on 2018/9/29.
 */
@SpringBootApplication
public class ServiceApplication {

    public static void main(String args[]) {

        SpringApplication.run(ServiceApplication.class, args);

    }
}
