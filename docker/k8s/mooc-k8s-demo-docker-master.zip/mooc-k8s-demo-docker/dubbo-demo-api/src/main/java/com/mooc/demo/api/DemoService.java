package com.mooc.demo.api;

/**
 * Created by Michael on 2018/9/25.
 */

public interface DemoService {

    String sayHello(String name);

}