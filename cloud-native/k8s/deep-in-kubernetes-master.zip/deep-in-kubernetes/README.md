# deep-in-kubernetes

kubernetes实践过程中用到的配置、脚本等